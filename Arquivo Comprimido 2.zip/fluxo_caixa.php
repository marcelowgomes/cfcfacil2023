<div class="container-fluid">
    <div class="header">
        <h1>Fluxo de Caixa</h1>
        <p class='mt-3'>Escolha uma opção abaixo</p>
        <div class='mt-3 d-flex'>
            <a href="entrada"><button class="btn btn-success">Entrada</button></a>
            <a href="saida"><button class='btn btn-danger mx-2'>Saída</button></a>
        </div>
    </div>
</div>
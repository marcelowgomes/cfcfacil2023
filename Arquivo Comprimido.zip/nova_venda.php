<?php // CODIGO DA SESSION

if (!empty($_SESSION['id_user'])) {
} else {
	$_SESSION['msg'] = "Área restrita";
	header("Location: login.php");
}

include_once 'bd/conexao.php';

$sql = "SELECT * from alunos WHERE aluno_id = '$id' and aluno_cfc = $user[user_empresa] ";
$sql2 = "SELECT * from receitas_despesas where receita_cfc = $user[user_empresa] ";
$sql3 = "SELECT * from colaboradores ";
$aluno = mysqli_query($conn, $sql);
$dados = mysqli_fetch_assoc($aluno);
$produtos = mysqli_query($conn, $sql2);
$produto_dados = mysqli_fetch_all($produto);
$colaborador = mysqli_query($conn, $sql3);
$pattern = '/\(\d+\)[ ]?\d+[-. ]?\d+/';
preg_match($pattern, $dados["aluno_telefones"], $matches);

$sqlcarv = "SELECT * from carrinho WHERE carrinho_aluno = '$id' and carrinho_status = '1' ";
$carv = mysqli_query($conn, $sqlcarv);
$crvtotal = mysqli_num_rows($carv);


?>
<style type="text/css">
        h1 {
            color:green;
        }
        .xyz {
            background-size: auto;
            text-align: center;
            padding-top: 100px;
        }
        .btn-circle.btn-sm {
            width: 30px;
            height: 30px;
            padding: 6px 0px;
            border-radius: 15px;
            font-size: 14px;
            text-align: center;
        }
        .btn-circle.btn-md {
            width: 50px;
            height: 50px;
            padding: 7px 10px;
            border-radius: 25px;
            font-size: 10px;
            text-align: center;
        }
        .btn-circle.btn-xl {
            width: 70px;
            height: 70px;
            padding: 10px 16px;
            border-radius: 35px;
            font-size: 12px;
            text-align: center;
        }
    </style>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<div>
                 
                 <div>
                    <h4>Nova Venda -   <?php echo ($dados['aluno_nome']) ?> </h4>
                    <div class='mt-2 d-flex'>
        <p><strong>CPF: </strong><?php echo ($dados['aluno_cpf']) ?></p>&nbsp; -
        <p class='mx-2'><strong>Telefone: </strong><?php echo ($matches[0]) ?></p>
      </div>
                 </div>  </div></div>

<br>


<div class="row">

<div class="col-5">
<div id="div-content" class="ap-po-details ap-po-details--2 p-25 radius-xl">


<div class="row ffp  justify-content-between "> 
<div class="col-7"><strong> Item </strong> </div> 
<div class="col-3"><strong> Valor </strong></div> 
<div class="col-2"><strong> Ação</strong> </div> 
</div> 


  <?php




  $x='0';
  while($produto = mysqli_fetch_array($produtos)) { 
  $x++;
  
  $sql2a = "SELECT * from carrinho  where carrinho_aluno = $id and carrinho_status='1' and carrinho_cfc = $user[user_empresa] and carrinho_item = $produto[receita_id]  ";
  $exe2a = mysqli_query($conn, $sql2a);
  $totalitens2a =mysqli_num_rows($exe2a);
  //echo  $totalitens2a ;
    ?>

    <form id="formapagar<?php echo $x ?>" action="#" method="post" enctype="multipart/form-data">

<div class="row ffp ffp--hover justify-content-between "> 
<div class="col-7 ffp__title">
  
                                                         <h6>
                                                         <?php echo $produto[receita_nome] ?>
                                                   
                                                      <p class="d-block">
                                                      <?php echo $produto[receita_observacoes] ?>
                                                      </p>
                                                   </div>





<div class="col-3">R$<?php echo $produto[receita_valor] ?> </div> 
<div class="col-2">


 <div id="qqId<?php echo $produto[receita_id] ?>">


</div> 
<input type="hidden" name="item"  value="<?php echo $produto[receita_id] ?>"> 
<input type="hidden" name="aluno"  value="<?php echo $id ?>"> 
<input type="hidden" name="categoria"  value="<?php echo $produto[receita_categoria] ?>"> 
<input type="hidden" name="subcategoria"  value="<?php echo $produto[receita_subcategoria] ?>"> 
<input type="hidden" name="valor"  value="<?php echo $produto[receita_valor] ?>"> 
<input type="hidden" name="custo"  value="<?php echo $produto[receita_custo] ?>"> 

</div> 

</div> 
  </form>

  <script>
$(document).ready(function() {
  var tempo = 000; //Dois segundos
  (function selectNumUsuarios () {
        $.ajax({
          url: "add_vendas.php?id=<?php echo $produto[receita_id] ?>",
          dataType: 'html',
          success: function (n) {
              //essa é a function success, será executada se a requisição obtiver exito
              $("#qqId<?php echo $produto[receita_id] ?>").html(n);
          },
          complete: function () {
              setTimeout(selectNumUsuarios, tempo);
          }
       });
    })();
});
</script>





<script>	
$(document).ready(function() {
 $("#formapagar<?php echo $x ?>").submit(function(){
var formData = new FormData(this);
  $.ajax({
    url: 'teste.php',
    cache: false,
    data: formData,
    type: "POST",  
    enctype: 'multipart/form-data',
    processData: false, // impedir que o jQuery tranforma a "data" em querystring
    contentType: false, // desabilitar o cabeçalho "Content-Type"
    success: function(msg){
      $("#results").empty();
      $("#results").append(msg);
      document.getElementById("divini").style.display = "none";

    }
  });
   return false;
 });
});
</script>


<?php } ?>


</div> 
  </div>




  <div class="col-7">
  
  <div class="col-xxl-12">
                     <div class="row">
                        <div class="col-xxl-12 col-sm-12 mb-25">
                           <!-- Card 1  -->
                           <div id="div-content" class="ap-po-details ap-po-details--2 p-25 radius-xl justify-content-between">
<div class="row ffp  justify-content-between "> 
<div class="col-3"><strong> Item </strong> </div> 
<div class="col-2"><strong> QTD </strong></div> 
<div class="col-2"><strong> Desconto(-) </strong></div> 
<div class="col-2"><strong> Acrescimo(+) </strong> </div> 
<div class="col-2"><strong> Total</strong> </div> 
<div class="col-1"><strong> Ação</strong> </div> 


</div>


  <!-- Se o carrinho já tiver item exibe o include   -->

  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<div id="carrinho"></div>
<script>

$( document ).ready(function() {
    var tempo = 0000; //Dois segundos

    (function selectNumUsuarios () {
        $.ajax({
          url: "carinicio.php?id=<?php echo $id ?>",
          success: function (n) {
              //essa é a function success, será executada se a requisição obtiver exito
              $("#carrinho").html(n);
          },
          complete: function () {
              setTimeout(selectNumUsuarios, tempo);
          }
       });
    })();
});


</script>








</div> </div> </div> </div>

  
  </div>


</div>



<?php 
if (!empty($_SESSION['id_user'])) {
} else {
    $_SESSION['msg'] = "Área restrita";
    header("Location: logar.php");
}

?>
<?php /// ALUNOS
$sqla = "SELECT * FROM alunos WHERE aluno_cfc = '$user[user_empresa]' and aluno_id = '$id'";
$exea = mysqli_query($conn, $sqla);
$aluno = mysqli_fetch_array($exea);
?>
  
 
       
               
      

         <div class="container-fluid">
            <div class="profile-content mb-50">
               <div class="row">
                  <div class="col-lg-12">

                     <div class="breadcrumb-main">
                        <h4 class="text-capitalize breadcrumb-title"><i class="uil uil-user"></i> Área do Aluno </h4>
                        <div class="breadcrumb-action justify-content-center flex-wrap">
                           <nav aria-label="breadcrumb">
                          
                           </nav>
                        </div>
                     </div>

                  </div>
                  <div class="col-xxl-3 col-md-4  ">
                     <aside class="profile-sider">
                        <!-- Profile Acoount -->
                        <div class="card mb-25">
                           <div class="card-body text-center pt-sm-30 pb-sm-0  px-25 pb-0">

                              <div class="account-profile">
                                 <div class="ap-img w-100 d-flex justify-content-center">
                                    <!-- Profile picture image-->
                                    <img class="ap-img__main rounded-circle mb-3  wh-120 d-flex bg-opacity-primary" src="img/author/profile.png" alt="profile">
                                 </div>
                                 <div class="ap-nameAddress pb-3 pt-1">
                                    <h5 class="ap-nameAddress__title"><?php echo $aluno['aluno_nome'] ?></h5>
                                    <p class="ap-nameAddress__subTitle fs-14 m-0"><?php echo $aluno['aluno_cpf'] ?></p>
                                    <p class="ap-nameAddress__subTitle fs-14 m-0">
                                     Processo categoria: &nbsp; <strong> <?php echo $aluno['aluno_categoria_pretendida'] ?></strong>
                                    </p>
                                 </div>
                                 <div class="ap-button button-group d-flex justify-content-center flex-wrap">
                                    <button type="button" class="border text-capitalize px-25 color-gray transparent radius-md">
                                       <img class="svg" src="img/svg/mail.svg" alt="mail">Enviar Mensagem</button>


                                   





                                 </div>
                              </div>

                              <div class="card-footer mt-20 pt-20 pb-20 px-0 bg-transparent">
                                 <div class="profile-overview d-flex justify-content-between flex-wrap">
                                    <div class="po-details">
                                       <h6 class="po-details__title pb-1">R$1250,57</h6>
                                       <span class="po-details__sTitle">Valor Investido</span>
                                    </div>
                                    <div class="po-details">
                                       <h6 class="po-details__title pb-1">3</h6>
                                       <span class="po-details__sTitle">Compras</span>
                                    </div>
                                    <div class="po-details">
                                       <h6 class="po-details__title pb-1">10</h6>
                                       <span class="po-details__sTitle">Aulas</span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- Profile Acoount End -->

                        <!-- Profile User Bio -->
                        <div class="card mb-25">
                          
                           <div class="user-info border-bottom">
                              <div class="card-header border-bottom-0 pt-sm-25 pb-sm-0  px-md-25 px-3">
                                 <div class="profile-header-title">
Dados de contato                                 </div>
                              </div>
                              <div class="card-body pt-md-1 pt-0">
                                 <div class="user-content-info">
                                    <p class="user-content-info__item">
                                       <img class="svg" src="img/svg/mail.svg" alt="mail"><?php echo $aluno['aluno_emails'] ?>
                                    </p>
                                    <p class="user-content-info__item">
                                       <img src="img/svg/phone.svg" alt="phone" class="svg"><?php echo $aluno['aluno_telefones'] ?>
                                    </p>
                                    <p class="user-content-info__item mb-0">
                                       <img src="img/svg/globe.svg" alt="globe" class="svg">www.example.com
                                    </p>
                                 </div>
                              </div>
                           </div>
                           <div class="user-skils border-bottom">
                              <div class="card-header border-bottom-0 pt-sm-25 pb-sm-0  px-md-25 px-3">
                                 <div class="profile-header-title">
                                    Alertas
                                 </div>
                              </div>
                              <div class="card-body pt-md-1 pt-0">
                                 <ul class="user-skils-parent">
                                    <li class="user-skils-parent__item">
                                       <a href="#">Exame Carro Marcado dia 23/02/2024</a>
                                    </li>
                                 </ul>
                                 
                              </div>
                           </div>
                          
                        </div>
                        <!-- Profile User Bio End -->
                     </aside>
                  </div>

                  <div class="col-xxl-9 col-md-8">
                     <!-- Tab Menu -->
                     <div class="ap-tab ap-tab-header">
                        <div class="ap-tab-header__img">
                           <img src="img/ap-header.png" alt="ap-header" class="img-fluid w-100">
                        </div>
                        <div class="ap-tab-wrapper">
                           <ul class="nav px-25 ap-tab-main" id="ap-tab" role="tablist">


                              <li class="nav-item">
                                 <a class="nav-link active" id="ap-overview-tab" data-bs-toggle="pill" href="#ap-resumo" role="tab" aria-selected="true">Resumo Financeiro</a>
                              </li>



                              <li class="nav-item">
                                 <a class="nav-link" id="timeline-tab" data-bs-toggle="pill" href="#timeline" role="tab" aria-selected="false">Crediário</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" id="activity-tab" data-bs-toggle="pill" href="#activity" role="tab" aria-selected="false">Taxas e Locação</a>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <!-- Tab Menu End -->



                     <div class="tab-content mt-25" id="ap-tabContent">
                        <div class="tab-pane fade show active" id="ap-resumo" role="tabpanel" aria-labelledby="ap-overview-tab">
                           <div class="ap-content-wrapper">
                              <div class="row">
                                 <div class="col-lg-4 mb-25">
                                   
                                 </div>
                                 <div class="col-lg-4 mb-25">
                                    
                                 </div>
                                 <div class="col-lg-4 mb-25">
                                   
                                 </div>
                                 <div class="col-lg-12">



                              
                                    <!-- Friend post -->
                                    <div class="card global-shadow mb-25">
                                       <div class="friends-widget">
                                          


                                       <div class="card-body p-0 py-10">


<!-- inicio card -->

<div class="ffp d-flex ffp--hover justify-content-between  align-items-center w-100">
                                                <div class="d-flex">
                                                   <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-success bg-opacity-success">
                                                      <i class="fas fa-arrow-up"></i>                                                      </span>
                                                   </div>
                                                   <div class="ffp__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>
                                                          Compra realizada no valor R$ 1300,00
                                                      </a>
                                                      <p class="d-block">
                                                         11/12/2022
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="ffp__button">


                                                   <div class="dropdown  dropdown-click ">

                                                      <button class="btn-link border-0 bg-transparent p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                         <img src="img/svg/more-horizontal.svg" alt="more-horizontal" class="svg">
                                                      </button>


                                                      <div class="dropdown-default dropdown-bottomRight dropdown-menu">
                                                         <a class="dropdown-item" href="#">Item One</a>
                                                         

                                                      </div>
                                                   </div>


                                                </div>
                                             </div>
<!-- fim card -->
                                

<!-- inicio card -->

<div class="ffp d-flex ffp--hover justify-content-between  align-items-center w-100">
                                                <div class="d-flex">
                                                   <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-danger bg-opacity-danger">
                                                      <i class="fas fa-arrow-down"></i>                                                      </span>
                                                   </div>
                                                   <div class="ffp__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>
                                                          Saida realizada no valor R$ 300,00
                                                      </a>
                                                      <p class="d-block">
                                                         11/12/2022
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="ffp__button">


                                                   <div class="dropdown  dropdown-click ">

                                                      <button class="btn-link border-0 bg-transparent p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                         <img src="img/svg/more-horizontal.svg" alt="more-horizontal" class="svg">
                                                      </button>


                                                      <div class="dropdown-default dropdown-bottomRight dropdown-menu">
                                                         <a class="dropdown-item" href="#">Detalhes</a>
                                                         

                                                      </div>
                                                   </div>


                                                </div>
                                             </div>

<!-- fim card -->



<!-- inicio card -->

<div class="ffp d-flex ffp--hover justify-content-between  align-items-center w-100">
                                                <div class="d-flex">
                                                   <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-success bg-opacity-success">
                                                      <i class="fas fa-clipboard-check"></i>                                                    </span>
                                                   </div>
                                                   <div class="ffp__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>
                                                          Crédiario Recebido no valor R$ 100,00
                                                      </a>
                                                      <p class="d-block">
                                                         11/12/2022
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="ffp__button">


                                                   <div class="dropdown  dropdown-click ">

                                                      <button class="btn-link border-0 bg-transparent p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                         <img src="img/svg/more-horizontal.svg" alt="more-horizontal" class="svg">
                                                      </button>


                                                      <div class="dropdown-default dropdown-bottomRight dropdown-menu">
                                                         <a class="dropdown-item" href="#">Item One</a>
                                                         

                                                      </div>
                                                   </div>


                                                </div>
                                             </div>
<!-- fim card -->



<!-- inicio card -->

                                             <div class="ffp d-flex ffp--hover justify-content-between  align-items-center w-100">
                                                <div class="d-flex">
                                                   <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-danger bg-opacity-danger">
                                                      <i class="fas fa-arrow-down"></i>                                                      </span>
                                                   </div>
                                                   <div class="ffp__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>
                                                          Saida realizada no valor R$ 300,00
                                                      </a>
                                                      <p class="d-block">
                                                         11/12/2022
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="ffp__button">


                                                   <div class="dropdown  dropdown-click ">

                                                      <button class="btn-link border-0 bg-transparent p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                         <img src="img/svg/more-horizontal.svg" alt="more-horizontal" class="svg">
                                                      </button>


                                                      <div class="dropdown-default dropdown-bottomRight dropdown-menu">
                                                         <a class="dropdown-item" href="#">Item One</a>
                                                         

                                                      </div>
                                                   </div>


                                                </div>
                                             </div>
<!-- fim card -->






                                             
                                             
                                  
                                 </div>  </div>  </div>
                                
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="tab-pane fade" id="timeline" role="tabpanel" aria-labelledby="timeline-tab">
                           <div class="ap-post-content">
                              <div class="row">
                       

                              <div class="col-xxl-6">
                                    <!-- Friend Widgets -->
                                    <div class="card global-shadow mb-25">
                                       <div class="friends-widget">
                                          <div class="card-header px-md-25 px-3">
                                             <h6>Parcelas a Receber</h6>
                                          </div>
                                          <div class="card-body p-0">
                                             <div class="ffw d-flex justify-content-between">
                                                <div class="d-flex flex-wrap">
                                                <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-success bg-opacity-success">
                                                      <i class="fas fa-clipboard-check"></i>                                                    </span>
</div>
                                                   <div class="ffw__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>Meyri Carles</h6>
                                                      </a>
                                                      <span class="d-block">
                                                         UI Designer
                                                      </span>
                                                   </div>
                                                </div>
                                                <div>



                                                   <button class="btn btn-default btn-squared color-light btn-outline-light friends-follow">follow
                                                   </button>




                                                </div>
                                             </div>
                                             
                                             
                                             
                                          </div>
                                       </div>
                                    </div>
                                    </div>

     

                                  

                             

                                 
                                 <div class="col-xxl-6">
                                    <!-- Friend Widgets -->
                                    <div class="card global-shadow mb-25">
                                       <div class="friends-widget">
                                          <div class="card-header px-md-25 px-3">
                                             <h6>Parcelas Recebidas</h6>
                                          </div>
                                          <div class="card-body p-0">
                                             <div class="ffw d-flex justify-content-between">
                                                <div class="d-flex flex-wrap">
                                                <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-success bg-opacity-success">
                                                      <i class="fas fa-clipboard-check"></i>                                                    </span>
                                                   </div>
                                                   <div class="ffw__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>Meyri Carles</h6>
                                                      </a>
                                                      <span class="d-block">
                                                         UI Designer
                                                      </span>
                                                   </div>
                                                </div>
                                                <div>



                                                   <button class="btn btn-default btn-squared color-light btn-outline-light friends-follow">follow
                                                   </button>




                                                </div>
                                             </div>
                                             
                                             
                                             
                                          </div>
                                       </div>
                                    </div>
                                    <!-- Friend Widgets End -->

                                   

                                    
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="tab-pane fade" id="activity" role="tabpanel" aria-labelledby="activity-tab">
                           <div class="ap-post-content">
                              <div class="row">
                                 <div class="col-xxl-12">
                                    <!-- Friend post -->
                                    <div class="card global-shadow mb-25">
                                       <div class="friends-widget">
                                          <div class="card-header px-md-25 px-3">
                                             <h6>Taxas</h6>
                                          </div>
                                          <div class="card-body p-0 py-10">
                                             <div class="ffp d-flex ffp--hover justify-content-between  align-items-center w-100">
                                                <div class="d-flex">
                                                   <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-primary bg-opacity-primary">
                                                         <img class="svg" src="img/svg/inbox.svg" alt="inbox">
                                                      </span>
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block avatar avatar-md m-0 " style="background-image:url('img/author/4.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffp__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>
                                                            <span class="color-primary">James</span> sent you a
                                                            message
                                                         </h6>
                                                      </a>
                                                      <p class="d-block">
                                                         5 hours ago
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="ffp__button">


                                                   <div class="dropdown  dropdown-click ">

                                                      <button class="btn-link border-0 bg-transparent p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                         <img src="img/svg/more-horizontal.svg" alt="more-horizontal" class="svg">
                                                      </button>


                                                      <div class="dropdown-default dropdown-bottomRight dropdown-menu">
                                                         <a class="dropdown-item" href="#">Item One</a>
                                                         <a class="dropdown-item" href="#">Item Two</a>
                                                         <a class="dropdown-item" href="#">Item Three</a>

                                                      </div>
                                                   </div>


                                                </div>
                                             </div>
                                             <div class="ffp d-flex ffp--hover justify-content-between  align-items-center w-100">
                                                <div class="d-flex">
                                                   <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-secondary bg-opacity-secondary">
                                                         <img class="svg" src="img/svg/upload.svg" alt="upload">
                                                      </span>
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block avatar avatar-md m-0 " style="background-image:url('img/author/1.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffp__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>
                                                            <span class="color-primary">Adam </span>upload
                                                            website template for sale
                                                         </h6>
                                                      </a>
                                                      <p class="d-block">
                                                         5 hours ago
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="ffp__button">


                                                   <div class="dropdown  dropdown-click ">

                                                      <button class="btn-link border-0 bg-transparent p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                         <img src="img/svg/more-horizontal.svg" alt="more-horizontal" class="svg">
                                                      </button>


                                                      <div class="dropdown-default dropdown-bottomRight dropdown-menu">
                                                         <a class="dropdown-item" href="#">Item One</a>
                                                         <a class="dropdown-item" href="#">Item Two</a>
                                                         <a class="dropdown-item" href="#">Item Three</a>

                                                      </div>
                                                   </div>


                                                </div>
                                             </div>
                                             <div class="ffp d-flex ffp--hover justify-content-between  align-items-center w-100">
                                                <div class="d-flex">
                                                   <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-success bg-opacity-success">
                                                         <img class="svg" src="img/svg/log-in.svg" alt="log-in"></span>
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block avatar avatar-md m-0 " style="background-image:url('img/author/4.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffp__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>
                                                            <span class="color-primary">Mumtahin </span>has
                                                            registered
                                                         </h6>
                                                      </a>
                                                      <p class="d-block">
                                                         5 hours ago
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="ffp__button">


                                                   <div class="dropdown  dropdown-click ">

                                                      <button class="btn-link border-0 bg-transparent p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                         <img src="img/svg/more-horizontal.svg" alt="more-horizontal" class="svg">
                                                      </button>


                                                      <div class="dropdown-default dropdown-bottomRight dropdown-menu">
                                                         <a class="dropdown-item" href="#">Item One</a>
                                                         <a class="dropdown-item" href="#">Item Two</a>
                                                         <a class="dropdown-item" href="#">Item Three</a>

                                                      </div>
                                                   </div>


                                                </div>
                                             </div>
                                             <div class="ffp d-flex ffp--hover justify-content-between  align-items-center w-100">
                                                <div class="d-flex">
                                                   <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-info bg-opacity-info">
                                                         <img class="svg" src="img/svg/at-sign.svg" alt="at-sign"></span>
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block avatar avatar-md m-0 " style="background-image:url('img/author/2.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffp__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>
                                                            <span class="color-primary">James </span>Send you a
                                                            message
                                                         </h6>
                                                      </a>
                                                      <p class="d-block">
                                                         5 hours ago
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="ffp__button">


                                                   <div class="dropdown  dropdown-click ">

                                                      <button class="btn-link border-0 bg-transparent p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                         <img src="img/svg/more-horizontal.svg" alt="more-horizontal" class="svg">
                                                      </button>


                                                      <div class="dropdown-default dropdown-bottomRight dropdown-menu">
                                                         <a class="dropdown-item" href="#">Item One</a>
                                                         <a class="dropdown-item" href="#">Item Two</a>
                                                         <a class="dropdown-item" href="#">Item Three</a>

                                                      </div>
                                                   </div>


                                                </div>
                                             </div>
                                             <div class="ffp d-flex ffp--hover justify-content-between  align-items-center w-100">
                                                <div class="d-flex align">
                                                   <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-danger bg-opacity-danger">
                                                         <img src="img/svg/heart.svg" alt="heart" class="svg"></span>
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block avatar avatar-md m-0 " style="background-image:url('img/author/3.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffp__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>
                                                            <span class="color-primary">Adam </span>upload
                                                            website template for sale
                                                         </h6>
                                                      </a>
                                                      <p class="d-block">
                                                         5 hours ago
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="ffp__button">


                                                   <div class="dropdown  dropdown-click ">

                                                      <button class="btn-link border-0 bg-transparent p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                         <img src="img/svg/more-horizontal.svg" alt="more-horizontal" class="svg">
                                                      </button>


                                                      <div class="dropdown-default dropdown-bottomRight dropdown-menu">
                                                         <a class="dropdown-item" href="#">Item One</a>
                                                         <a class="dropdown-item" href="#">Item Two</a>
                                                         <a class="dropdown-item" href="#">Item Three</a>

                                                      </div>
                                                   </div>


                                                </div>
                                             </div>
                                             <div class="ffp d-flex ffp--hover justify-content-between  align-items-center w-100">
                                                <div class="d-flex">
                                                   <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-warning bg-opacity-warning">
                                                         <img class="svg" src="img/svg/message-square.svg" alt="message-square"></span>
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block avatar avatar-md m-0 " style="background-image:url('img/author/4.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffp__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>
                                                            <span class="color-primary">James</span> sent you a
                                                            message
                                                         </h6>
                                                      </a>
                                                      <p class="d-block">
                                                         5 hours ago
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="ffp__button">


                                                   <div class="dropdown  dropdown-click ">

                                                      <button class="btn-link border-0 bg-transparent p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                         <img src="img/svg/more-horizontal.svg" alt="more-horizontal" class="svg">
                                                      </button>


                                                      <div class="dropdown-default dropdown-bottomRight dropdown-menu">
                                                         <a class="dropdown-item" href="#">Item One</a>
                                                         <a class="dropdown-item" href="#">Item Two</a>
                                                         <a class="dropdown-item" href="#">Item Three</a>

                                                      </div>
                                                   </div>


                                                </div>
                                             </div>
                                             <div class="ffp d-flex ffp--hover justify-content-between  align-items-center w-100">
                                                <div class="d-flex">
                                                   <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-secondary bg-opacity-secondary">
                                                         <img class="svg" src="img/svg/upload.svg" alt="upload"></span>
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block avatar avatar-md m-0" style="background-image:url('img/author/1.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffp__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>
                                                            <span class="color-primary">Shreyu Neu</span> sent
                                                            you a
                                                            message
                                                         </h6>
                                                      </a>
                                                      <p class="d-block">
                                                         5 hours ago
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="ffp__button">


                                                   <div class="dropdown  dropdown-click ">

                                                      <button class="btn-link border-0 bg-transparent p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                         <img src="img/svg/more-horizontal.svg" alt="more-horizontal" class="svg">
                                                      </button>


                                                      <div class="dropdown-default dropdown-bottomRight dropdown-menu">
                                                         <a class="dropdown-item" href="#">Item One</a>
                                                         <a class="dropdown-item" href="#">Item Two</a>
                                                         <a class="dropdown-item" href="#">Item Three</a>

                                                      </div>
                                                   </div>


                                                </div>
                                             </div>
                                             <div class="ffp d-flex ffp--hover justify-content-between  align-items-center w-100">
                                                <div class="d-flex">
                                                   <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-success bg-opacity-success">
                                                         <img class="svg" src="img/svg/log-in.svg" alt="log-in"></span>
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block avatar avatar-md m-0 " style="background-image:url('img/author/4.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffp__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>
                                                            <span class="color-primary">Mumtahin </span>has
                                                            registered
                                                         </h6>
                                                      </a>
                                                      <p class="d-block">
                                                         5 hours ago
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="ffp__button">


                                                   <div class="dropdown  dropdown-click ">

                                                      <button class="btn-link border-0 bg-transparent p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                         <img src="img/svg/more-horizontal.svg" alt="more-horizontal" class="svg">
                                                      </button>


                                                      <div class="dropdown-default dropdown-bottomRight dropdown-menu">
                                                         <a class="dropdown-item" href="#">Item One</a>
                                                         <a class="dropdown-item" href="#">Item Two</a>
                                                         <a class="dropdown-item" href="#">Item Three</a>

                                                      </div>
                                                   </div>


                                                </div>
                                             </div>
                                             <div class="ffp d-flex ffp--hover justify-content-between  align-items-center w-100">
                                                <div class="d-flex">
                                                   <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-info bg-opacity-info">
                                                         <img class="svg" src="img/svg/at-sign.svg" alt="at-sign"></span>
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block avatar avatar-md m-0 " style="background-image:url('img/author/2.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffp__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>
                                                            <span class="color-primary">James </span>Send you a
                                                            message
                                                         </h6>
                                                      </a>
                                                      <p class="d-block">
                                                         5 hours ago
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="ffp__button">


                                                   <div class="dropdown  dropdown-click ">

                                                      <button class="btn-link border-0 bg-transparent p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                         <img src="img/svg/more-horizontal.svg" alt="more-horizontal" class="svg">
                                                      </button>


                                                      <div class="dropdown-default dropdown-bottomRight dropdown-menu">
                                                         <a class="dropdown-item" href="#">Item One</a>
                                                         <a class="dropdown-item" href="#">Item Two</a>
                                                         <a class="dropdown-item" href="#">Item Three</a>

                                                      </div>
                                                   </div>


                                                </div>
                                             </div>
                                             <div class="ffp d-flex ffp--hover justify-content-between  align-items-center w-100">
                                                <div class="d-flex align">
                                                   <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-danger bg-opacity-danger">
                                                         <img src="img/svg/heart.svg" alt="heart" class="svg"></span>
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block avatar avatar-md m-0 " style="background-image:url('img/author/3.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffp__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>
                                                            <span class="color-primary">Adam </span>upload
                                                            website template for sale
                                                         </h6>
                                                      </a>
                                                      <p class="d-block">
                                                         5 hours ago
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="ffp__button">


                                                   <div class="dropdown  dropdown-click ">

                                                      <button class="btn-link border-0 bg-transparent p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                         <img src="img/svg/more-horizontal.svg" alt="more-horizontal" class="svg">
                                                      </button>


                                                      <div class="dropdown-default dropdown-bottomRight dropdown-menu">
                                                         <a class="dropdown-item" href="#">Item One</a>
                                                         <a class="dropdown-item" href="#">Item Two</a>
                                                         <a class="dropdown-item" href="#">Item Three</a>

                                                      </div>
                                                   </div>


                                                </div>
                                             </div>
                                             <div class="ffp d-flex ffp--hover justify-content-between  align-items-center w-100">
                                                <div class="d-flex">
                                                   <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-warning bg-opacity-warning">
                                                         <img class="svg" src="img/svg/message-square.svg" alt="message-square"></span>
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block avatar avatar-md m-0 " style="background-image:url('img/author/4.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffp__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>
                                                            <span class="color-primary">James</span> sent you a
                                                            message
                                                         </h6>
                                                      </a>
                                                      <p class="d-block">
                                                         5 hours ago
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="ffp__button">


                                                   <div class="dropdown  dropdown-click ">

                                                      <button class="btn-link border-0 bg-transparent p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                         <img src="img/svg/more-horizontal.svg" alt="more-horizontal" class="svg">
                                                      </button>


                                                      <div class="dropdown-default dropdown-bottomRight dropdown-menu">
                                                         <a class="dropdown-item" href="#">Item One</a>
                                                         <a class="dropdown-item" href="#">Item Two</a>
                                                         <a class="dropdown-item" href="#">Item Three</a>

                                                      </div>
                                                   </div>


                                                </div>
                                             </div>
                                             <div class="ffp d-flex ffp--hover justify-content-between  align-items-center w-100">
                                                <div class="d-flex">
                                                   <div class="me-3 ffp__imgWrapper d-flex align-items-center">
                                                      <span class="ffp__icon color-secondary bg-opacity-secondary">
                                                         <img class="svg" src="img/svg/upload.svg" alt="upload"></span>
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block avatar avatar-md m-0" style="background-image:url('img/author/1.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffp__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>
                                                            <span class="color-primary">Shreyu Neu</span> sent
                                                            you a
                                                            message
                                                         </h6>
                                                      </a>
                                                      <p class="d-block">
                                                         5 hours ago
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="ffp__button">


                                                   <div class="dropdown  dropdown-click ">

                                                      <button class="btn-link border-0 bg-transparent p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                         <img src="img/svg/more-horizontal.svg" alt="more-horizontal" class="svg">
                                                      </button>


                                                      <div class="dropdown-default dropdown-bottomRight dropdown-menu">
                                                         <a class="dropdown-item" href="#">Item One</a>
                                                         <a class="dropdown-item" href="#">Item Two</a>
                                                         <a class="dropdown-item" href="#">Item Three</a>

                                                      </div>
                                                   </div>


                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- Friend Post End -->
                                 </div>
                                 <div class="col-xxl-12">
                                    <!-- Friend Widgets -->
                                    <div class="card global-shadow mb-25">
                                       <div class="friends-widget">
                                          <div class="card-header px-md-25 px-3">
                                             <h6>Locação</h6>
                                          </div>
                                          <div class="card-body p-0">
                                             <div class="ffw d-flex justify-content-between">
                                                <div class="d-flex flex-wrap">
                                                   <div class="me-3 ffw__imgWrapper">
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block ap-profile-image " style="background-image:url('img/author/4.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffw__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>Meyri Carles</h6>
                                                      </a>
                                                      <span class="d-block">
                                                         UI Designer
                                                      </span>
                                                   </div>
                                                </div>
                                                <div>



                                                   <button class="btn btn-default btn-squared color-light btn-outline-light friends-follow">follow
                                                   </button>




                                                </div>
                                             </div>
                                             <div class="ffw d-flex justify-content-between">
                                                <div class="d-flex flex-wrap">
                                                   <div class="me-3 ffw__imgWrapper">
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block ap-profile-image " style="background-image:url('img/author/1.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffw__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>Shreyu Neu</h6>
                                                      </a>
                                                      <span class="d-block">
                                                         Product Designer
                                                      </span>
                                                   </div>
                                                </div>
                                                <div class="ffw__button">



                                                   <button class="btn btn-default btn-squared color-light btn-outline-light friends-follow"><img src="img/svg/check.svg" alt="check" class="svg">
                                                      follow
                                                   </button>




                                                </div>
                                             </div>
                                             <div class="ffw d-flex justify-content-between">
                                                <div class="d-flex flex-wrap">
                                                   <div class="me-3 ffw__imgWrapper">
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block ap-profile-image " style="background-image:url('img/author/4.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffw__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>Domnic Harris</h6>
                                                      </a>
                                                      <span class="d-block">
                                                         Executive Assistant
                                                      </span>
                                                   </div>
                                                </div>
                                                <div class="ffw__button">



                                                   <button class="btn btn-default btn-squared color-light btn-outline-light friends-follow"><img src="img/svg/check.svg" alt="check" class="svg">
                                                      follow
                                                   </button>




                                                </div>
                                             </div>
                                             <div class="ffw d-flex justify-content-between">
                                                <div class="d-flex flex-wrap">
                                                   <div class="me-3 ffw__imgWrapper">
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block ap-profile-image " style="background-image:url('img/author/2.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffw__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>Khalid Hasan</h6>
                                                      </a>
                                                      <span class="d-block">
                                                         UI director
                                                      </span>
                                                   </div>
                                                </div>
                                                <div class="ffw__button">



                                                   <button class="btn btn-default btn-squared color-light btn-outline-light friends-follow"><img src="img/svg/check.svg" alt="check" class="svg">
                                                      follow
                                                   </button>




                                                </div>
                                             </div>
                                             <div class="ffw d-flex justify-content-between">
                                                <div class="d-flex flex-wrap">
                                                   <div class="me-3 ffw__imgWrapper">
                                                      <span class=" profile-image bg-opacity-secondary rounded-circle d-block ap-profile-image " style="background-image:url('img/author/3.jpg'); background-size: cover;"></span>
                                                   </div>
                                                   <div class="ffw__title">
                                                      <a href="#" class="text-dark fw-500">
                                                         <h6>Tuhin Molla</h6>
                                                      </a>
                                                      <span class="d-block">
                                                         System Administrator
                                                      </span>
                                                   </div>
                                                </div>
                                                <div class="ffw__button">



                                                   <button class="btn btn-default btn-squared color-light btn-outline-light friends-follow"><img src="img/svg/check.svg" alt="check" class="svg">
                                                      follow
                                                   </button>




                                                </div>
                                             </div>
                                             <a class="view-more-comment color-primary fs-13 fw-500 px-25 pb-20" href="#">Load more friends</a>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- Friend Widgets End -->


                                   
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>

      </div>
      <footer class="footer-wrapper">
         <div class="footer-wrapper__inside">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-md-6">
                     <div class="footer-copyright">
                        <p><span>© 2023</span><a href="#">Sovware</a>
                        </p>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="footer-menu text-end">
                        <ul>
                           <li>
                              <a href="#">About</a>
                           </li>
                           <li>
                              <a href="#">Team</a>
                           </li>
                           <li>
                              <a href="#">Contact</a>
                           </li>
                        </ul>
                     </div>
                     <!-- ends: .Footer Menu -->
                  </div>
               </div>
            </div>
         </div>
      </footer>
   </main>
   <div id="overlayer">
      <div class="loader-overlay">
         <div class="dm-spin-dots spin-lg">
            <span class="spin-dot badge-dot dot-primary"></span>
            <span class="spin-dot badge-dot dot-primary"></span>
            <span class="spin-dot badge-dot dot-primary"></span>
            <span class="spin-dot badge-dot dot-primary"></span>
         </div>
      </div>
   </div>
   <div class="overlay-dark-sidebar"></div>
   <div class="customizer-overlay"></div>
   <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyBgYKHZB_QKKLWfIRaYPCadza3nhTAbv7c"></script>
  
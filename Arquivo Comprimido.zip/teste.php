<?php
session_start();
include_once "bd/conexao.php";
$iduser = $_SESSION['id_user'];
$sqluser = "SELECT * FROM usuarios WHERE id_user = '$iduser'";
$exeuser = mysqli_query($conn, $sqluser);
$user = mysqli_fetch_array($exeuser);


$qtd = '1';;
$item = $_POST['item'];
$sub = $_POST['subcategoria'];
$cat = $_POST['categoria'];
$valor = $_POST['valor'];
$aluno = $_POST['aluno'];
$oco = 'Entrada';
$custo = $_POST['custo'];


$sql2 = "SELECT * from carrinho  where carrinho_aluno = $aluno and carrinho_status='1' and carrinho_cfc = $user[user_empresa] and carrinho_item = $item ";
$exe2 = mysqli_query($conn, $sql2);
$totalitens =mysqli_num_rows($exe2);



if($totalitens == '0') {
@$conn->query($insert = "INSERT INTO carrinho (carrinho_item, carrinho_qtd, carrinho_usuario, carrinho_aluno ,
carrinho_cfc,carrinho_categoria, carrinho_subcategoria, carrinho_ocorrencia	,carrinho_valorun, carrinho_custo) VALUES ('$item','$qtd','$user[id_user]','$aluno','$user[user_empresa]','$cat','$sub','$oco','$valor','$custo')");
 } else {
$conn->query("update carrinho set carrinho_qtd	 = carrinho_qtd	+  1  where carrinho_aluno = $aluno and carrinho_status='1' and carrinho_cfc = $user[user_empresa] and carrinho_item = $item  ");
 }


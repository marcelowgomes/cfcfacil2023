<?php
session_start();
include_once "bd/conexao.php";
$iduser = $_SESSION['id_user'];
$sqluser = "SELECT * FROM usuarios WHERE id_user = '$iduser'";
$exeuser = mysqli_query($conn, $sqluser);
$user = mysqli_fetch_array($exeuser);


$qtd = '1';
$item = $_POST['item'];
$sub = $_POST['subcategoria'];
$cat = $_POST['categoria'];
$valor = $_POST['valor'];
$aluno = $_POST['aluno'];
$oco = 'Entrada';
$custo = $_POST['custo'];




$conn->query("update carrinho set carrinho_qtd = $_POST[qtd] where carrinho_id = $_POST[id] ");
 

$sql = "SELECT * from carrinho c inner join receitas_despesas rd ON c.carrinho_item = rd.receita_id where c.carrinho_aluno = $aluno and c.carrinho_status='1' and c.carrinho_cfc = $user[user_empresa] ";
$exe = mysqli_query($conn, $sql);
$y=0;
while($linha = mysqli_fetch_array($exe)) { 
$y++;
$totalitem2 = $linha[receita_valor] * $linha[carrinho_qtd]  ;

?>



<form id="for2<?php echo $y ?>" action="#" method="post" >

<div class="row ffp ffp--hover justify-content-between "> 
<div class="col-3 ffp__title">
  
                                                         <h6> 
                                                         <?php echo $linha[receita_nome] ?>
                                                   
                                                      <p class="d-block">
                                                      <?php echo $linha[receita_observacoes] ?>
                                                      </p>
                                                   </div>


<div class="col-2"><strong> <input type="number" name="qtd" class="form-control" required min="1" value="<?php echo $linha[carrinho_qtd] ?>">  </strong></div> 
<div class="col-2"><strong> <input type="number" name="desconto" class="form-control" required value="<?php echo $linha[carrinho_desconto] ?>"> </strong></div> 
<div class="col-2"><strong> <input type="number" name="acrescimo" class="form-control" value="<?php echo $linha[carrinho_acrescimo] ?>"></strong> </div> 
<div class="col-2"><strong> R$2<?php echo number_format($totalitem2 , 2, ',', '.'); ?></strong> </div> 
<div class="col-1"><strong> <div class="row"> <div class="col-6">    <button type="submit" class="btn btn-info btn-circle btn-sm">&#8635;</button>  </div>  <div class="col-6">    <button type="submit" class="btn btn-danger btn-circle btn-sm">x</button>  </div> </div>  </strong> </div> 
<input type="hidden" name="aluno"  value="<?php echo $aluno ?>"> 





</div> 

</div> 
  </form>

 
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

  <script>	
$(document).ready(function() {
 $("#for2<?php echo $y ?>").submit(function(){
var formData = new FormData(this);
  $.ajax({
    url: 'teste2.php',
    cache: false,
    data: formData,
    type: "POST",  
    enctype: 'multipart/form-data',
    processData: false, // impedir que o jQuery tranforma a "data" em querystring
    contentType: false, // desabilitar o cabeçalho "Content-Type"
    success: function(msg){
      $("#results2").empty();
      $("#results2").append(msg);
      document.getElementById("results").style.display = "none";

    }
  });
   return false;
 });
});
</script>
<?php
}
?>
